import './custom-js/global'
import '#template/js/admin'
